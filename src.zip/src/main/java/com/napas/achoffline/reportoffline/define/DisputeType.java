package com.napas.achoffline.reportoffline.define;

public enum DisputeType {
    RQAD,RQRN,RQNF,RQSP,GDFT
}
