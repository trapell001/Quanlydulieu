package com.napas.achoffline.reportoffline.define;

public enum ReportRtpFunctionParameter {
    DATE_BEGIN,
    DATE_END,
    SESSION_BEGIN,
    SESSION_END,
    PARTICIPANT_TYPE,
    BIC,
    PARTICIPAN_ROLE,
    SERVICE,
    STATUS
}
