package com.napas.achoffline.reportoffline.define;

public enum ReportDisputeFunctionParameter {
    DATE_BEGIN,
    DATE_END,
    SESSION_BEGIN,
    SESSION_END,
    PARTICIPANT_TYPE,
    BIC,
    BOC,
    TTC,
    TRANS_TYPE,
    PARTICIPAN_ROLE,
    DISPUTE_TYPE,
    RESPONSE_DATE,
    SERVICE
}
