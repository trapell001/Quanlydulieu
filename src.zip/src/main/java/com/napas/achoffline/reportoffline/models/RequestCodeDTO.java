package com.napas.achoffline.reportoffline.models;

import lombok.Data;

@Data
public class RequestCodeDTO {

    private String code;

    private String state;
}
