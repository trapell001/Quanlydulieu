package com.napas.achoffline.reportoffline.define;

public enum ReportDnsFunctionParameter {
    DATE_BEGIN,
    DATE_END,
    SESSION_BEGIN,
    SESSION_END,
    PARTICIPANT_TYPE,
    BIC,
    BOC,
    TTC,
    TRANS_TYPE,
    PARTICIPAN_ROLE,
    STATUS
}
