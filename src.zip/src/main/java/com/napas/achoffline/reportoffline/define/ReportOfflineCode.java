/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package com.napas.achoffline.reportoffline.define;

/**
 *
 * @author huynx
 */
public enum ReportOfflineCode {
    RO_02,
    RO_03_SEND_TO_BANK,
    RO_03_NAPAS,
    RO_04,
    RO_06_SEND_TO_BANK,
    RO_06_A,
    RO_06_B,
    RO_07,
    RO_08,
    RO_09,
    RO_10,
    RO_11,
    RO_01
}
