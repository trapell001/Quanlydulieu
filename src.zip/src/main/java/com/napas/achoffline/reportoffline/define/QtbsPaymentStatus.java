/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package com.napas.achoffline.reportoffline.define;

import com.fasterxml.jackson.annotation.JsonValue;

/**
 *
 * @author huynx
 */
public enum QtbsPaymentStatus {
    CREATED, APPROVED, DECLINE;
}
